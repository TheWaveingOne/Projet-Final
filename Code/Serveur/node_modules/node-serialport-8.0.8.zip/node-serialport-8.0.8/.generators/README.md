# @serialport/{{pascalCase name}}

This is a node SerialPort project! This package does some neat stuff.

- [Guides and API Docs](https://serialport.io/)

This is why you'd use it.

This is how you use it.
```js
const {{camelCase name}} = new {{pascalCase name}}()

```
