See our api docs See our api docs https://serialport.io/docs/api-parser-readline
